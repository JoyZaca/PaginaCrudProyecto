async function submitData() {
    const electricity = document.getElementById('electricity').value || 0;
    const gas = document.getElementById('gas').value || 0;
    const water = document.getElementById('water').value || 0;

    const data = { electricity, gas, water };

    try {
        const response = await fetch('submit_data.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        displayResult(result);
    } catch (error) {
        console.error('Error al enviar los datos:', error);
    }
}

function displayResult(result) {
    const { electricityEmissions, gasEmissions, waterEmissions, totalEmissions } = result;

     document.getElementById('usageResult').innerText = `Tu consumo de energía es aproximadamente ${totalEmissions.toFixed(2)} kg CO2 por mes.`;

    const ctx = document.getElementById('usageChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Electricidad', 'Gas', 'Agua'],
            datasets: [{
                label: 'Emisiones de CO2 (kg)',
                data: [electricityEmissions, gasEmissions, waterEmissions],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}