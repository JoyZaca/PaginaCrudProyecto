async function loadMonthlyData() {
    try {
        const response = await fetch('statistics.php', {
            method: 'GET',  // o POST dependiendo de cómo manejes la consulta en PHP
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const result = await response.json();
        displayMonthlyData(result);
    } catch (error) {
        console.error('Error al cargar los datos mensuales:', error);
    }
}

function displayMonthlyData(data) {
    const ctx = document.getElementById('monthlyUsageChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Electricidad', 'Gas', 'Agua'],
            datasets: [{
                label: 'Consumo Mensual (Unidades)',
                data: [data.electricity, data.gas, data.water],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    loadMonthlyData();
});