<?php
$servername = "localhost";
$username = "id22199848_hector";
$password = "Hosting$23";
$dbname = "id22199848_ecodashboard";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Ahora la conexión está establecida, puedes proceder a consultar las tablas

// Ejemplo de consulta a la tabla "users"
$sql_users = "SELECT * FROM users";
$result_users = $conn->query($sql_users);

if ($result_users->num_rows > 0) {
    // Procesar los datos de la tabla users
    while($row = $result_users->fetch_assoc()) {
        echo "Nombre: " . $row["nombre"]. " - Email: " . $row["email"]. "<br>";
    }
} else {
    echo "0 resultados encontrados en la tabla users";
}

// Ejemplo de consulta a la tabla "usage_data"
$sql_usage_data = "SELECT * FROM usage_data";
$result_usage_data = $conn->query($sql_usage_data);

if ($result_usage_data->num_rows > 0) {
    // Procesar los datos de la tabla usage_data
    while($row = $result_usage_data->fetch_assoc()) {
        echo "ID: " . $row["id"]. " - Datos: " . $row["datos"]. "<br>";
    }
} else {
    echo "0 resultados encontrados en la tabla usage_data";
}

// Cerrar la conexión
?>