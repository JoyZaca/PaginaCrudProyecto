<?php
require_once 'conexion.php';

// Verificar si se enviaron datos de inicio de sesión
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validación de inicio de sesión (ejemplo básico)
    $sql = "SELECT * FROM users WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // Inicio de sesión exitoso
        session_start();
        $_SESSION['username'] = $username;

        // Registrar el inicio de sesión en la base de datos (opcional)
        $login_time = date('Y-m-d H:i:s');
        $insert_sql = "INSERT INTO login_history (username, login_time) VALUES (?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("ss", $username, $login_time);
        $insert_stmt->execute();

        // Redirigir al panel de control o página principal después del inicio de sesión
        header("Location: index.html");
        exit();
    } else {
        // Error de inicio de sesión
        $error_message = "Nombre de usuario o contraseña incorrectos.";
    }

    // Cerrar la declaración de consulta
    $stmt->close();
}

// Cerrar la conexión a la base de datos al finalizar el script
$conn->close();
?>
