<?php
session_start();
include 'conexion.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}

// Obtener el nombre de usuario de la sesión
$username = $_SESSION['username'];

// Preparar consulta para obtener los datos de consumo del mes actual del usuario
$stmt = $conn->prepare("SELECT electricity, gas, water FROM usage_data WHERE username = ? AND month = MONTH(CURDATE()) AND year = YEAR(CURDATE())");
if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
}

// Asociar parámetros y ejecutar la consulta
$stmt->bind_param("s", $username);
$stmt->execute();

// Obtener resultados
$result = $stmt->get_result();
$consumption = $result->fetch_assoc();

// Verificar si no hay datos para el usuario y asignar valores por defecto
if ($consumption === null) {
    $consumption = ['electricity' => 0, 'gas' => 0, 'water' => 0];
}

$stmt->close();
$conn->close();
?>