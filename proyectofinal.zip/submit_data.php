<?php
header('Content-Type: application/json');

// Recibe los datos del POST
$data = json_decode(file_get_contents('php://input'), true);

$electricity = isset($data['electricity']) ? floatval($data['electricity']) : 0;
$gas = isset($data['gas']) ? floatval($data['gas']) : 0;
$water = isset($data['water']) ? floatval($data['water']) : 0;

// Factores de emisión (ejemplos, los valores reales pueden variar)
$electricityEmissionFactor = 0.5; // kg CO2 por hora de uso
$gasEmissionFactor = 2.1; // kg CO2 por hora de uso
$waterEmissionFactor = 0.001; // kg CO2 por litro

// Cálculo de emisiones
$electricityEmissions = $electricity * $electricityEmissionFactor;
$gasEmissions = $gas * $gasEmissionFactor;
$waterEmissions = $water * $waterEmissionFactor;
$totalEmissions = $electricityEmissions + $gasEmissions + $waterEmissions;

// Conexión a la base de datos
$servername = "localhost"; // Cambia esto si tu servidor de BD es diferente
$username = "id22199848_hector"; // Reemplaza con tu usuario de la BD
$password = "Hosting$23"; // Reemplaza con tu contraseña de la BD
$dbname = "id22199848_ecodashboard"; // Reemplaza con el nombre de tu BD

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Inserción de datos en la tabla usage_data
$sql = "INSERT INTO usage_data (electricity, gas, water) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ddd", $electricity, $gas, $water);

if ($stmt->execute()) {
    $result = array(
        'status' => 'success',
        'message' => 'Datos guardados exitosamente',
        'electricityEmissions' => $electricityEmissions,
        'gasEmissions' => $gasEmissions,
        'waterEmissions' => $waterEmissions,
        'totalEmissions' => $totalEmissions
    );
} else {
    $result = array(
        'status' => 'error',
        'message' => 'Error al guardar los datos: ' . $stmt->error
    );
}

// Cerrar la conexión
$stmt->close();
$conn->close();

// Enviar respuesta en formato JSON
echo json_encode($result);
?>
